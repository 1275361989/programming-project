void removeChildren( Node *parent );
