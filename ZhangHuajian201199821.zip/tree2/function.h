#include "stdio.h"
#include "stdlib.h"

#include "math.h"





double nodeValue( Node *node, double time );
double value( double x, double y, double time );









