void adapt( Node *head );
void giveflag(Node *head);
void changetree(Node *head);
