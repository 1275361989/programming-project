void destroyTree(Node *parent );
